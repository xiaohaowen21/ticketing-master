package com.alipay.api.response;


import com.alipay.api.AlipayResponse;

/**
 * ALIPAY API: alipay.eco.mycar.trade.refund response.
 * 
 * @author auto create
 * @since 1.0, 2019-08-29 11:19:27
 */
public class AlipayEcoMycarTradeRefundResponse extends AlipayResponse {

	private static final long serialVersionUID = 8677897243772113246L;

	

	

}
