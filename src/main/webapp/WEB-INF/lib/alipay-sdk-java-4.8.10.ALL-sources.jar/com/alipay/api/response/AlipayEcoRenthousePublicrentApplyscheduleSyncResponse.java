package com.alipay.api.response;


import com.alipay.api.AlipayResponse;

/**
 * ALIPAY API: alipay.eco.renthouse.publicrent.applyschedule.sync response.
 * 
 * @author auto create
 * @since 1.0, 2019-01-07 20:51:15
 */
public class AlipayEcoRenthousePublicrentApplyscheduleSyncResponse extends AlipayResponse {

	private static final long serialVersionUID = 5543295337795128323L;

	

	

}
