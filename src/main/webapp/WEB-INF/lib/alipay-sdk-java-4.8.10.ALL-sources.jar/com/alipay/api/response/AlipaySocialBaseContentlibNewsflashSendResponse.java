package com.alipay.api.response;


import com.alipay.api.AlipayResponse;

/**
 * ALIPAY API: alipay.social.base.contentlib.newsflash.send response.
 * 
 * @author auto create
 * @since 1.0, 2019-01-07 20:51:15
 */
public class AlipaySocialBaseContentlibNewsflashSendResponse extends AlipayResponse {

	private static final long serialVersionUID = 8118255628594462162L;

	

	

}
