package com.alipay.api.response;


import com.alipay.api.AlipayResponse;

/**
 * ALIPAY API: ant.merchant.expand.item.security.delete response.
 * 
 * @author auto create
 * @since 1.0, 2019-09-06 14:26:05
 */
public class AntMerchantExpandItemSecurityDeleteResponse extends AlipayResponse {

	private static final long serialVersionUID = 1853927411151782899L;

	

	

}
