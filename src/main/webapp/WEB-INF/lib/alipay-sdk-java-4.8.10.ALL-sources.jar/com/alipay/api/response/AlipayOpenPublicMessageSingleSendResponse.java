package com.alipay.api.response;


import com.alipay.api.AlipayResponse;

/**
 * ALIPAY API: alipay.open.public.message.single.send response.
 * 
 * @author auto create
 * @since 1.0, 2019-10-10 10:52:48
 */
public class AlipayOpenPublicMessageSingleSendResponse extends AlipayResponse {

	private static final long serialVersionUID = 8523647689344985432L;

	

	

}
