package com.alipay.api.response;


import com.alipay.api.AlipayResponse;

/**
 * ALIPAY API: alipay.commerce.cityfacilitator.deposit.cancel response.
 * 
 * @author auto create
 * @since 1.0, 2019-01-07 20:51:15
 */
public class AlipayCommerceCityfacilitatorDepositCancelResponse extends AlipayResponse {

	private static final long serialVersionUID = 4362481561859316968L;

	

	

}
