package com.alipay.api.response;


import com.alipay.api.AlipayResponse;

/**
 * ALIPAY API: alipay.commerce.iot.device.delete response.
 * 
 * @author auto create
 * @since 1.0, 2019-01-07 20:51:15
 */
public class AlipayCommerceIotDeviceDeleteResponse extends AlipayResponse {

	private static final long serialVersionUID = 4449492552478239986L;

	

	

}
