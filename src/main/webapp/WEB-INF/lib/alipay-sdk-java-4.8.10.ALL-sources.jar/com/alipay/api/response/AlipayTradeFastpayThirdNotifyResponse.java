package com.alipay.api.response;


import com.alipay.api.AlipayResponse;

/**
 * ALIPAY API: alipay.trade.fastpay.third.notify response.
 * 
 * @author auto create
 * @since 1.0, 2019-01-07 20:51:15
 */
public class AlipayTradeFastpayThirdNotifyResponse extends AlipayResponse {

	private static final long serialVersionUID = 1376879344411511438L;

	

	

}
