package com.alipay.api.response;


import com.alipay.api.AlipayResponse;

/**
 * ALIPAY API: alipay.commerce.iot.device.personalinfo.modify response.
 * 
 * @author auto create
 * @since 1.0, 2019-01-07 20:51:15
 */
public class AlipayCommerceIotDevicePersonalinfoModifyResponse extends AlipayResponse {

	private static final long serialVersionUID = 6698284734641768849L;

	

	

}
